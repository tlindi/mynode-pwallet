 MyNodeBTC Marketplace Community App from https://github.com/Hodladi/pWallet2.0

./dist contains .tar.gz to be uploaded

NO WARRANTIES OF ANY KIND!

TAKE, KEEP AND VERYFY BACKUP DATA RESTORABILITY BY YOURSELF!
---

[X] nothing ToDo

### pWallet version
* v2.0.9 (v8)

### Installation and startup fixes
* Installation done only if phoenixd configuration is found.
* starts only after phoenixd service.

### install time variable setting
* make sed to end of line from "ApiPassword" always cause "SET BY USER" might have been "nulled" previous faulty run