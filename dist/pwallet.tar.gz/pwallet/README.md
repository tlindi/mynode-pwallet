./dist contains .tar.gz to be uploaded onto MyNodeBTC Marketplace Community App.

NO WARRANTIES OF ANY KIND!

TAKE, KEEP AND VERYFY BACKUP DATA RESTORABILITY BY YOURSELF!
---

# ToDo

### service starting
* requires phoenixd to run before starting

# Known Issues
- initiates installation, which fails, when phoenixd is not installed.

# Completed improvements

### install time variable setting
* make sed to end of line from "ApiPassword" always cause "SET BY USER" might have been "nulled" preious faulty run
