./dist contains .tar.gz to be uploaded onto MyNodeBTC Marketplace Community App.

NO WARRANTIES OF ANY KIND!

TAKE, KEEP AND VERYFY BACKUP DATA RESTORABILITY BY YOURSELF!
---

[X] nothing ToDo

### service starting
# Completed improvements

### install time variable setting
* make sed to end of line from "ApiPassword" always cause "SET BY USER" might have been "nulled" preious faulty run

### Installation and startup fixes
* Installation done only if phoenixd configuration is found.
* starts only after phoenixd service.

