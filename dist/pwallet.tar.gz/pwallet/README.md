Initial Release pWallet2.0 + tlindi PRs 20250419

version v2.0-tlindi
MyNodeBTC pwallet MyNode SDK build Community App
https://github.com/Hodladi/pWallet2.0 from fork repo
https://www.github.com/tlindi/pwallet2.0

Note!!! MyNodeBTC can use github made tar.gz
- Use mynode-pwallet-v2.0-tlindi.tar.gz

Full Changelog: https://github.com/tlindi/mynode-pwallet/commits/v2.0-tlindi